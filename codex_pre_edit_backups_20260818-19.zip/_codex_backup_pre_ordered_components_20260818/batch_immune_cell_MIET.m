function [summary, batchInfo] = batch_immune_cell_MIET(dataRoot, cfg)
%BATCH_IMMUNE_CELL_MIET Analyze suitable immune-cell MIET PTUs recursively.
%
% [summary, batchInfo] = batch_immune_cell_MIET(dataRoot, cfg)
%
% Every RawImage.ptu below dataRoot is audited and written to the summary.
% By default, only complete, high-dwell XY scans are sent to
% immune_cell_MIET. The image-derived result is then labelled as a good cell
% experiment only when segmentation, cell/SLB support, lifetime contrast,
% and Bayesian coverage pass configurable QC thresholds.
%
% Important cfg fields (all optional):
%   scanPlanes                 planes to analyze (default {'XY'})
%   minDwellMs                 metadata prefilter (default 0.4 ms/pixel)
%   minCompletionFraction      empirical raster completion (default 0.95)
%   minRecords                 minimum TTTR records (default 1e6)
%   resume                     reuse a valid existing result (default true)
%   overwrite                  recompute existing results (default false)
%   dryRun                     header audit only (default false)
%   saveTcspcPix               save detector-summed uint16 cube (default true)
%   pipeline                   options passed to immune_cell_MIET
%   qc                         image-derived good-cell QC overrides
%
% Folder-level outputs are checkpointed after every file in
% <dataRoot>/immune_cell_MIET_batch. Per-acquisition images and MAT files
% remain in <acquisition>/immune_cell_MIET. No photon stream is placed in a
% batch output.

    if nargin < 1 || isempty(dataRoot)
        dataRoot = 'E:\Luminosa_data\260813\4deg_Jurkat_CD58_memglow';
    end
    if nargin < 2 || isempty(cfg)
        cfg = struct();
    end
    cfg = fillBatchDefaults(cfg);
    dataRoot = char(dataRoot);
    if ~isfolder(dataRoot)
        error('batch_immune_cell_MIET:MissingRoot', ...
            'Data root was not found: %s', dataRoot);
    end
    requireFunction('PTU_Read_Head');
    requireFunction('immune_cell_MIET_scan_geometry');
    if ~cfg.dryRun
        requireFunction('immune_cell_MIET');
    end

    outputDir = cfg.batchOutputDir;
    if isempty(outputDir)
        outputDir = fullfile(dataRoot, 'immune_cell_MIET_batch');
    end
    if ~isfolder(outputDir)
        mkdir(outputDir);
    end
    csvFile = fullfile(outputDir, 'immune_cell_MIET_batch_summary.csv');
    matFile = fullfile(outputDir, 'immune_cell_MIET_batch_summary.mat');
    errorLogFile = fullfile(outputDir, 'immune_cell_MIET_batch_errors.log');

    files = dir(fullfile(dataRoot, '**', 'RawImage.ptu'));
    if isempty(files)
        error('batch_immune_cell_MIET:NoFiles', ...
            'No RawImage.ptu files were found below %s.', dataRoot);
    end
    fullNames = arrayfun(@(x) fullfile(x.folder, x.name), files, ...
        'UniformOutput', false);
    [~, order] = sort(fullNames);
    files = files(order);

    rows = repmat(emptyRow(), numel(files), 1);
    fprintf('batch_immune_cell_MIET: auditing %d PTU files below %s\n', ...
        numel(files), dataRoot);
    for fileIndex = 1:numel(files)
        ptuFile = fullfile(files(fileIndex).folder, files(fileIndex).name);
        rows(fileIndex) = initialiseRow(rows(fileIndex), fileIndex, ...
            files(fileIndex), ptuFile);
        try
            % The repository contains both one- and two-argument copies of
            % PTU_Read_Head. One argument is compatible with both.
            head = PTU_Read_Head(ptuFile);
            geometry = immune_cell_MIET_scan_geometry(head);
            rows(fileIndex) = addHeaderMetadata(rows(fileIndex), head, ...
                geometry, cfg.excitationPulseIndex);
            [rows(fileIndex).preflightEligible, ...
                rows(fileIndex).preflightReason] = preflightDecision( ...
                rows(fileIndex), head, cfg);
            if rows(fileIndex).preflightEligible
                rows(fileIndex).status = 'eligible';
            else
                rows(fileIndex).status = 'skipped_preflight';
            end
        catch headerError
            rows(fileIndex).status = 'header_failed';
            rows(fileIndex).preflightEligible = false;
            rows(fileIndex).preflightReason = cleanText(headerError.message);
            rows(fileIndex).errorIdentifier = headerError.identifier;
            rows(fileIndex).message = cleanText(headerError.message);
            appendErrorLog(errorLogFile, ptuFile, headerError);
        end
    end

    [summary, batchInfo] = checkpoint(rows, cfg, dataRoot, outputDir, ...
        csvFile, matFile, errorLogFile);
    if cfg.dryRun
        fprintf('batch_immune_cell_MIET: dry run complete; no PTU was analyzed.\n');
        printSummary(batchInfo, csvFile);
        return;
    end

    eligibleIndices = find([rows.preflightEligible]);
    if isfinite(cfg.maxFiles)
        eligibleIndices = eligibleIndices(1:min(numel(eligibleIndices), ...
            floor(cfg.maxFiles)));
    end
    for position = 1:numel(eligibleIndices)
        fileIndex = eligibleIndices(position);
        ptuFile = rows(fileIndex).ptuFile;
        analysisMat = rows(fileIndex).analysisMat;
        fprintf('batch_immune_cell_MIET: %d/%d eligible (%d/%d total): %s\n', ...
            position, numel(eligibleIndices), fileIndex, numel(rows), ptuFile);
        started = tic;
        figuresBefore = findall(groot, 'Type', 'figure');
        figureCleanup = onCleanup(@() closeNewPipelineFigures(figuresBefore));
        try
            localCfg = cfg.pipeline;
            localCfg.outputDir = rows(fileIndex).analysisDir;
            localCfg.showFigure = cfg.showFigures;
            localCfg.saveOutputs = true;
            localCfg.saveTcspcPix = cfg.saveTcspcPix;
            reused = false;
            if cfg.resume && ~cfg.overwrite && isfile(analysisMat)
                loaded = load(analysisMat, 'result');
                if isfield(loaded, 'result') && isstruct(loaded.result) && ...
                        existingResultUsable(analysisMat, loaded.result, ...
                        cfg.saveTcspcPix, ptuFile, localCfg)
                    result = loaded.result;
                    reused = true;
                end
            end
            if reused
                rows(fileIndex).action = 'reused_existing_result';
            else
                result = immune_cell_MIET(ptuFile, localCfg);
                rows(fileIndex).action = 'processed';
            end
            rows(fileIndex) = addResultQc(rows(fileIndex), result, cfg.qc);
            if rows(fileIndex).goodCell
                if reused
                    rows(fileIndex).status = 'existing_good_cell';
                else
                    rows(fileIndex).status = 'complete_good_cell';
                end
            else
                if reused
                    rows(fileIndex).status = 'existing_qc_reject';
                else
                    rows(fileIndex).status = 'complete_qc_reject';
                end
            end
            clear result loaded
        catch analysisError
            rows(fileIndex).status = 'analysis_failed';
            rows(fileIndex).action = 'attempted';
            rows(fileIndex).goodCell = false;
            rows(fileIndex).qcReason = cleanText(analysisError.message);
            rows(fileIndex).errorIdentifier = analysisError.identifier;
            rows(fileIndex).message = cleanText(analysisError.message);
            appendErrorLog(errorLogFile, ptuFile, analysisError);
            if ~cfg.continueOnError
                rows(fileIndex).processingSeconds = toc(started);
                clear figureCleanup
                checkpoint(rows, cfg, dataRoot, ...
                    outputDir, csvFile, matFile, errorLogFile);
                rethrow(analysisError);
            end
        end
        rows(fileIndex).processingSeconds = toc(started);
        clear figureCleanup
        checkpoint(rows, cfg, dataRoot, outputDir, ...
            csvFile, matFile, errorLogFile);
    end

    unprocessedEligible = setdiff(find([rows.preflightEligible]), eligibleIndices);
    for k = 1:numel(unprocessedEligible)
        idx = unprocessedEligible(k);
        rows(idx).status = 'eligible_not_run_max_files';
        rows(idx).action = 'not_run';
    end
    [summary, batchInfo] = checkpoint(rows, cfg, dataRoot, outputDir, ...
        csvFile, matFile, errorLogFile);
    printSummary(batchInfo, csvFile);
end

function cfg = fillBatchDefaults(cfg)
    defaults = struct();
    defaults.scanPlanes = {'XY'};
    defaults.minDwellMs = 0.4;
    defaults.minCompletionFraction = 0.95;
    defaults.minRecords = 1e6;
    defaults.requiredPieWindows = 2;
    defaults.excitationPulseIndex = 2;
    defaults.requiredExcitationNm = 640;
    defaults.wavelengthToleranceNm = 10;
    defaults.requireMetadataForPrefilter = true;
    defaults.resume = true;
    defaults.overwrite = false;
    defaults.dryRun = false;
    defaults.continueOnError = true;
    defaults.maxFiles = Inf;
    defaults.showFigures = false;
    defaults.saveTcspcPix = true;
    defaults.batchOutputDir = '';
    defaults.pipeline = struct();
    defaults.qc = struct('acceptedSegmentationStatuses', {{'ok'}}, ...
        'minCellFraction', 0.01, 'maxCellFraction', 0.85, ...
        'rejectCellTouchingBorder', true, ...
        'minSlbReferenceFraction', 0.01, ...
        'minSlbReferencePhotons', 500, ...
        'maxSlbRobustSigmaNs', 0.15, ...
        'minLifetimeContrastNs', 0.05, ...
        'minBayesCoverage', 0.25, ...
        'slbLifetimeRangeNs', [0.03 5]);
    cfg = mergeStruct(defaults, cfg);
    cfg.qc = mergeStruct(defaults.qc, cfg.qc);
    if ischar(cfg.scanPlanes) || (isstring(cfg.scanPlanes) && isscalar(cfg.scanPlanes))
        cfg.scanPlanes = {char(cfg.scanPlanes)};
    elseif isstring(cfg.scanPlanes)
        cfg.scanPlanes = cellstr(cfg.scanPlanes(:));
    end
    if ~iscellstr(cfg.scanPlanes) || isempty(cfg.scanPlanes)
        error('batch_immune_cell_MIET:ScanPlanes', ...
            'cfg.scanPlanes must contain one or more plane names.');
    end
    cfg.scanPlanes = cellfun(@upper, cfg.scanPlanes, 'UniformOutput', false);
    validateattributes(cfg.minDwellMs, {'numeric'}, {'scalar','nonnegative'});
    validateattributes(cfg.minCompletionFraction, {'numeric'}, ...
        {'scalar','nonnegative'});
    validateattributes(cfg.minRecords, {'numeric'}, {'scalar','nonnegative'});
    validateattributes(cfg.maxFiles, {'numeric'}, {'scalar','positive'});
end

function row = emptyRow()
    row = struct( ...
        'index', NaN, 'acquisition', '', 'ptuFile', '', ...
        'analysisDir', '', 'analysisMat', '', 'preliminaryPng', '', ...
        'segmentationPng', '', 'bayesPng', '', ...
        'fileBytes', NaN, 'scanDirection', NaN, 'scanPlane', 'unknown', ...
        'scanConfidence', 'low', 'scanReason', '', ...
        'pixelX', NaN, 'pixelY', NaN, 'pixelSizeUm', NaN, ...
        'dwellMs', NaN, 'elapsedMs', NaN, 'expectedRasterMs', NaN, ...
        'completionFraction', NaN, 'bidirectional', NaN, ...
        'headerMaxFrames', NaN, ...
        'numberOfRecords', NaN, 'pieWindows', NaN, ...
        'recordedExcitationNm', NaN, 'tcspcResolutionPs', NaN, ...
        'preflightEligible', false, 'preflightReason', '', ...
        'status', 'not_audited', 'action', 'not_run', ...
        'goodCell', false, 'qcReason', '', 'segmentationStatus', '', ...
        'cellPixels', NaN, 'cellFraction', NaN, ...
        'cellTouchesBorder', NaN, ...
        'slbReferencePixels', NaN, 'slbReferenceFraction', NaN, ...
        'slbReferencePhotons', NaN, 'slbRobustSigmaNs', NaN, ...
        'lifetimeContrastNs', NaN, 'fixedSlbLifetimeNs', NaN, ...
        'bayesValidPixels', NaN, 'bayesCoverage', NaN, ...
        'processingSeconds', NaN, 'errorIdentifier', '', 'message', '');
end

function row = initialiseRow(row, fileIndex, fileInfo, ptuFile)
    row.index = fileIndex;
    row.ptuFile = ptuFile;
    row.fileBytes = double(fileInfo.bytes);
    row.acquisition = acquisitionName(fileInfo.folder);
    row.analysisDir = fullfile(fileInfo.folder, 'immune_cell_MIET');
    row.analysisMat = fullfile(row.analysisDir, ...
        'immune_cell_MIET_640nm_red_analysis.mat');
    row.preliminaryPng = fullfile(row.analysisDir, ...
        'immune_cell_MIET_640nm_red_preliminary_mean_FLIM.png');
    row.segmentationPng = fullfile(row.analysisDir, ...
        'immune_cell_MIET_640nm_red_segmentation_check.png');
    row.bayesPng = fullfile(row.analysisDir, ...
        'immune_cell_MIET_640nm_red_Bayes_maps.png');
end

function name = acquisitionName(folder)
    [~, name] = fileparts(folder);
    if isempty(name)
        name = folder;
    end
end

function row = addHeaderMetadata(row, head, geometry, excitationPulseIndex)
    row.scanPlane = geometry.plane;
    row.scanConfidence = geometry.confidence;
    row.scanDirection = numericScalar(head, 'ImgHdr_ScanDirection');
    row.scanReason = cleanText(strjoin(geometry.reasons, ' | '));
    row.pixelX = numericScalar(head, 'ImgHdr_PixX');
    row.pixelY = numericScalar(head, 'ImgHdr_PixY');
    row.pixelSizeUm = numericScalar(head, 'ImgHdr_PixResol');
    row.dwellMs = numericScalar(head, 'ImgHdr_TimePerPixel');
    row.elapsedMs = numericScalar(head, 'TTResult_StopAfter');
    row.bidirectional = numericScalar(head, 'ImgHdr_BiDirect');
    row.headerMaxFrames = numericScalar(head, 'ImgHdr_MaxFrames');
    row.numberOfRecords = numericScalar(head, 'TTResult_NumberOfRecords');
    row.pieWindows = numericScalar(head, 'PIENumPIEWindows');
    resolutionSeconds = numericScalar(head, 'MeasDesc_Resolution');
    if isfinite(resolutionSeconds)
        row.tcspcResolutionPs = resolutionSeconds * 1e12;
    end
    if isfield(head, 'LaserWL') && isnumeric(head.LaserWL)
        wavelengths = double(head.LaserWL(:));
        if numel(wavelengths) >= excitationPulseIndex
            row.recordedExcitationNm = wavelengths(excitationPulseIndex);
        end
    end
    passFactor = 2;
    if isfinite(row.bidirectional) && row.bidirectional ~= 0
        passFactor = 1;
    end
    if all(isfinite([row.pixelX, row.pixelY, row.dwellMs])) && ...
            row.pixelX > 0 && row.pixelY > 0 && row.dwellMs > 0
        % This completion metric is deliberately single-frame. MaxFrames is
        % a configured maximum, not proof of how many frames were acquired.
        row.expectedRasterMs = passFactor * row.pixelX * ...
            row.pixelY * row.dwellMs;
        if isfinite(row.elapsedMs) && row.expectedRasterMs > 0
            row.completionFraction = row.elapsedMs / row.expectedRasterMs;
        end
    end
end

function [eligible, reason] = preflightDecision(row, head, cfg)
    failures = {};
    if ~any(strcmpi(row.scanPlane, cfg.scanPlanes))
        failures{end + 1} = sprintf('scan plane %s is not selected (%s)', ...
            row.scanPlane, strjoin(cfg.scanPlanes, ', '));
    end
    failures = requireThreshold(failures, row.dwellMs, cfg.minDwellMs, ...
        'dwell time', 'ms/pixel', cfg.requireMetadataForPrefilter);
    failures = requireThreshold(failures, row.completionFraction, ...
        cfg.minCompletionFraction, 'empirical raster completion', '', ...
        cfg.requireMetadataForPrefilter);
    failures = requireThreshold(failures, row.numberOfRecords, cfg.minRecords, ...
        'TTTR record count', 'records', cfg.requireMetadataForPrefilter);
    if ~isfinite(row.headerMaxFrames)
        if cfg.requireMetadataForPrefilter
            failures{end + 1} = 'maximum-frame metadata is missing';
        end
    elseif row.headerMaxFrames ~= 1
        failures{end + 1} = sprintf([ ...
            'ImgHdr_MaxFrames=%g is not supported by the single-frame ' ...
            'completion prefilter'], row.headerMaxFrames);
    end
    if ~isfinite(row.pieWindows)
        if cfg.requireMetadataForPrefilter
            failures{end + 1} = 'PIE-window count is missing';
        end
    elseif row.pieWindows < cfg.requiredPieWindows
        failures{end + 1} = sprintf('only %g PIE windows are recorded', ...
            row.pieWindows);
    end
    wavelength = row.recordedExcitationNm;
    if ~isfinite(wavelength)
        if cfg.requireMetadataForPrefilter
            failures{end + 1} = sprintf('pulse-%d wavelength is missing', ...
                cfg.excitationPulseIndex);
        end
    elseif abs(wavelength - cfg.requiredExcitationNm) > cfg.wavelengthToleranceNm
        failures{end + 1} = sprintf('pulse %d is %g nm, not %g nm', ...
            cfg.excitationPulseIndex, wavelength, cfg.requiredExcitationNm);
    end
    if ~(isfield(head, 'ImgHdr_PixX') && isfield(head, 'ImgHdr_PixY'))
        failures{end + 1} = 'image dimensions are missing';
    end
    eligible = isempty(failures);
    if eligible
        reason = sprintf(['eligible: %s, dwell %.4g ms/pixel, completion %.3f, ' ...
            '%.4g million records'], row.scanPlane, row.dwellMs, ...
            row.completionFraction, row.numberOfRecords / 1e6);
    else
        reason = cleanText(strjoin(failures, '; '));
    end
end

function failures = requireThreshold(failures, value, threshold, label, unit, required)
    if ~isfinite(value)
        if required
            failures{end + 1} = sprintf('%s metadata is missing', label);
        end
    elseif value < threshold
        if isempty(unit)
            failures{end + 1} = sprintf('%s %.4g is below %.4g', ...
                label, value, threshold);
        else
            failures{end + 1} = sprintf('%s %.4g %s is below %.4g', ...
                label, value, unit, threshold);
        end
    end
end

function row = addResultQc(row, result, qc)
    reasons = {};
    if isfield(result, 'segmentation') && ...
            isfield(result.segmentation, 'diagnostics')
        diagnostics = result.segmentation.diagnostics;
    else
        error('batch_immune_cell_MIET:ResultSegmentation', ...
            'Existing result has no segmentation diagnostics.');
    end
    row.segmentationStatus = char(diagnostics.status);
    counts = diagnostics.pixelCounts;
    row.cellPixels = double(counts.cellMembrane);
    row.slbReferencePixels = double(counts.slbReference);
    imagePixels = double(counts.image);
    row.cellFraction = row.cellPixels / max(imagePixels, 1);
    row.slbReferenceFraction = row.slbReferencePixels / max(imagePixels, 1);
    row.lifetimeContrastNs = double(diagnostics.cell.contrastOverSlbNs);
    row.cellTouchesBorder = logical(diagnostics.cell.touchesImageBorder);
    row.slbReferencePhotons = double(diagnostics.slb.referencePhotonCount);
    row.slbRobustSigmaNs = double(diagnostics.slb.robustSigmaNs);
    if isfield(result, 'slbReference') && ...
            isfield(result.slbReference, 'fixedLifetimeNs')
        row.fixedSlbLifetimeNs = double(result.slbReference.fixedLifetimeNs);
    end
    if isfield(result, 'bayesian') && isfield(result.bayesian, 'maps') && ...
            isfield(result.bayesian.maps, 'completeExponentialCountMAP')
        orderMap = result.bayesian.maps.completeExponentialCountMAP;
        row.bayesValidPixels = nnz(double(orderMap) > 0);
        row.bayesCoverage = row.bayesValidPixels / max(row.cellPixels, 1);
    end

    if ~any(strcmp(row.segmentationStatus, qc.acceptedSegmentationStatuses))
        reasons{end + 1} = sprintf('segmentation status is %s', ...
            row.segmentationStatus);
    end
    if row.cellFraction < qc.minCellFraction
        reasons{end + 1} = sprintf('cell fraction %.3g is below %.3g', ...
            row.cellFraction, qc.minCellFraction);
    elseif row.cellFraction > qc.maxCellFraction
        reasons{end + 1} = sprintf('cell fraction %.3g exceeds %.3g', ...
            row.cellFraction, qc.maxCellFraction);
    end
    if qc.rejectCellTouchingBorder && row.cellTouchesBorder
        reasons{end + 1} = 'segmented cell footprint touches the image border';
    end
    if row.slbReferenceFraction < qc.minSlbReferenceFraction
        reasons{end + 1} = sprintf('SLB-reference fraction %.3g is below %.3g', ...
            row.slbReferenceFraction, qc.minSlbReferenceFraction);
    end
    if ~isfinite(row.slbReferencePhotons) || ...
            row.slbReferencePhotons < qc.minSlbReferencePhotons
        reasons{end + 1} = sprintf('SLB-reference photons %.4g are below %.4g', ...
            row.slbReferencePhotons, qc.minSlbReferencePhotons);
    end
    if ~isfinite(row.slbRobustSigmaNs) || ...
            row.slbRobustSigmaNs > qc.maxSlbRobustSigmaNs
        reasons{end + 1} = sprintf([ ...
            'outside-SLB robust spread %.3g ns exceeds %.3g ns; ' ...
            'the fixed component is not sufficiently homogeneous'], ...
            row.slbRobustSigmaNs, qc.maxSlbRobustSigmaNs);
    end
    if ~isfinite(row.lifetimeContrastNs) || ...
            row.lifetimeContrastNs < qc.minLifetimeContrastNs
        reasons{end + 1} = sprintf('mean-arrival contrast %.3g ns is below %.3g ns', ...
            row.lifetimeContrastNs, qc.minLifetimeContrastNs);
    end
    if ~isfinite(row.bayesCoverage) || row.bayesCoverage < qc.minBayesCoverage
        reasons{end + 1} = sprintf('Bayesian coverage %.3g is below %.3g', ...
            row.bayesCoverage, qc.minBayesCoverage);
    end
    tauRange = qc.slbLifetimeRangeNs;
    if ~isfinite(row.fixedSlbLifetimeNs) || row.fixedSlbLifetimeNs < tauRange(1) || ...
            row.fixedSlbLifetimeNs > tauRange(2)
        reasons{end + 1} = sprintf('fixed SLB lifetime %.3g ns is outside [%g %g] ns', ...
            row.fixedSlbLifetimeNs, tauRange(1), tauRange(2));
    end
    row.goodCell = isempty(reasons);
    if row.goodCell
        row.qcReason = 'passed image-derived good-cell QC';
    else
        row.qcReason = cleanText(strjoin(reasons, '; '));
    end
end

function usable = existingResultUsable(matFile, result, requireTcspcPix, ...
        expectedSourceFile, expectedConfig)
    usable = isfield(result, 'segmentation') && ...
        isfield(result.segmentation, 'diagnostics') && ...
        isfield(result.segmentation.diagnostics, 'pixelCounts') && ...
        isfield(result, 'slbReference') && ...
        isfield(result.slbReference, 'fixedLifetimeNs') && ...
        isfield(result, 'bayesian') && isfield(result.bayesian, 'maps') && ...
        isfield(result.bayesian.maps, 'completeExponentialCountMAP');
    if ~usable || ~isfield(result, 'sourceFile') || ...
            ~strcmpi(char(result.sourceFile), char(expectedSourceFile)) || ...
            ~isfield(result, 'config') || ...
            ~structContainsExpectedConfig(result.config, ...
            analysisConfig(expectedConfig))
        usable = false;
        return;
    end
    if ~requireTcspcPix
        return;
    end
    variables = whos('-file', matFile);
    names = {variables.name};
    cubeIndex = find(strcmp(names, 'tcspc_pix'), 1);
    usable = ~isempty(cubeIndex) && ...
        strcmp(variables(cubeIndex).class, 'uint16');
end

function cfg = analysisConfig(cfg)
    operationalFields = {'outputDir', 'showFigure', 'showWaitbar', ...
        'saveOutputs', 'saveTcspcPix'};
    present = operationalFields(isfield(cfg, operationalFields));
    if ~isempty(present)
        cfg = rmfield(cfg, present);
    end
end

function matches = structContainsExpectedConfig(actual, expected)
    matches = isstruct(actual) && isscalar(actual) && ...
        isstruct(expected) && isscalar(expected);
    if ~matches
        return;
    end
    names = fieldnames(expected);
    for k = 1:numel(names)
        name = names{k};
        if ~isfield(actual, name)
            matches = false;
            return;
        end
        if isstruct(expected.(name)) && isscalar(expected.(name)) && ...
                isstruct(actual.(name)) && isscalar(actual.(name))
            matches = structContainsExpectedConfig(actual.(name), expected.(name));
        else
            matches = isequaln(actual.(name), expected.(name));
        end
        if ~matches
            return;
        end
    end
end

function [summary, batchInfo] = checkpoint(rows, cfg, dataRoot, outputDir, ...
        csvFile, matFile, errorLogFile)
    summary = struct2table(rows);
    batchInfo = buildBatchInfo(rows, dataRoot, outputDir, csvFile, ...
        matFile, errorLogFile);
    writetable(summary, csvFile);
    save(matFile, 'summary', 'batchInfo', 'cfg', '-v7.3');
end

function info = buildBatchInfo(rows, dataRoot, outputDir, csvFile, matFile, errorLog)
    statuses = {rows.status};
    info = struct();
    info.pipeline = 'immune_cell_MIET';
    info.generatedAt = datestr(now, 30);
    info.dataRoot = dataRoot;
    info.outputDir = outputDir;
    info.csvFile = csvFile;
    info.matFile = matFile;
    info.errorLogFile = errorLog;
    info.totalFiles = numel(rows);
    info.xyFiles = nnz(strcmp({rows.scanPlane}, 'XY'));
    info.xzFiles = nnz(strcmp({rows.scanPlane}, 'XZ'));
    info.yzFiles = nnz(strcmp({rows.scanPlane}, 'YZ'));
    info.eligibleFiles = nnz([rows.preflightEligible]);
    info.goodCellFiles = nnz([rows.goodCell]);
    info.failedFiles = nnz(contains(statuses, 'failed'));
    info.containsPhotonStream = false;
    info.scanConvention = [ ...
        'Dataset-derived Luminosa mapping: ImgHdr_ScanDirection ' ...
        '0=XY, 1=YZ, 2=XZ.'];
    info.completionDefinition = [ ...
        'TTResult_StopAfter divided by expected raster milliseconds; ' ...
        'unidirectional scans use an empirically validated factor of two.'];
end

function printSummary(info, csvFile)
    fprintf(['batch_immune_cell_MIET: %d total (%d XY, %d XZ, %d YZ); ' ...
        '%d metadata-eligible; %d good cells; %d failures.\n'], ...
        info.totalFiles, info.xyFiles, info.xzFiles, info.yzFiles, ...
        info.eligibleFiles, info.goodCellFiles, info.failedFiles);
    fprintf('batch_immune_cell_MIET: summary saved to %s\n', csvFile);
end

function appendErrorLog(logFile, ptuFile, errorObject)
    fid = fopen(logFile, 'a');
    if fid < 0
        warning('batch_immune_cell_MIET:ErrorLog', ...
            'Could not append the batch error log: %s', logFile);
        return;
    end
    cleanup = onCleanup(@() fclose(fid));
    fprintf(fid, '\n[%s] %s\n%s: %s\n', datestr(now, 31), ptuFile, ...
        errorObject.identifier, errorObject.message);
    for k = 1:numel(errorObject.stack)
        fprintf(fid, '  at %s (line %d)\n', ...
            errorObject.stack(k).name, errorObject.stack(k).line);
    end
    clear cleanup
end

function closeNewPipelineFigures(figuresBefore)
    figuresAfter = findall(groot, 'Type', 'figure');
    for k = 1:numel(figuresAfter)
        if ~any(figuresBefore == figuresAfter(k)) && isgraphics(figuresAfter(k))
            try
                close(figuresAfter(k));
            catch
            end
        end
    end
end

function value = numericScalar(s, fieldName)
    value = NaN;
    if isstruct(s) && isfield(s, fieldName) && ...
            (isnumeric(s.(fieldName)) || islogical(s.(fieldName))) && ...
            ~isempty(s.(fieldName))
        candidate = double(s.(fieldName)(1));
        if isfinite(candidate)
            value = candidate;
        end
    end
end

function text = cleanText(text)
    if isstring(text)
        text = char(text);
    end
    text = strrep(text, sprintf('\r'), ' ');
    text = strrep(text, newline, ' | ');
    text = strtrim(text);
end

function requireFunction(name)
    if exist(name, 'file') ~= 2
        error('batch_immune_cell_MIET:MissingDependency', ...
            'Required function %s.m is not on the MATLAB path.', name);
    end
end

function out = mergeStruct(out, overrides)
    if isempty(overrides)
        return;
    end
    names = fieldnames(overrides);
    for k = 1:numel(names)
        out.(names{k}) = overrides.(names{k});
    end
end
