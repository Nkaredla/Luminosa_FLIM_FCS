%RUN_BATCH_IMMUNE_CELL_MIET Analyze all suitable cell acquisitions in a folder.
dataRoot = 'E:\Luminosa_data\260813\4deg_Jurkat_CD58_memglow';

cfg = struct();
cfg.scanPlanes = {'XY'};          % Cross-sections are catalogued, not fitted.
cfg.minDwellMs = 0.4;             % Excludes fast overview/test scans.
cfg.minCompletionFraction = 0.95; % Excludes interrupted raster scans.
cfg.minRecords = 1e6;
cfg.resume = true;                % Reuse valid per-acquisition MAT results.
cfg.overwrite = false;
cfg.dryRun = false;               % Set true for a fast header-only audit.
cfg.continueOnError = true;
cfg.showFigures = false;          % PNG figures are still saved.
cfg.saveTcspcPix = true;          % Detector-summed, reassigned uint16 cube.

pipelineCfg = struct();
pipelineCfg.excitationPulseIndex = 2;
pipelineCfg.excitationNm = 640;
pipelineCfg.ismWavelengthNm = 690;
pipelineCfg.tcspcBinNs = 0.16;    % Exact multiple of both 40-ps and 20-ps data.
pipelineCfg.minPhotonsPerPixel = 3;
pipelineCfg.lifetimeRangeNs = [0.5 1.8];
pipelineCfg.showWaitbar = false;
pipelineCfg.useGPU = false;
pipelineCfg.bayesMinPhotons = 5;
pipelineCfg.segmentation = struct( ...
    'smoothSigma', 2.0, ...
    'minLifetimeContrastNs', 0.05, ...
    'cellSeparationSigma', 1.5, ...
    'growthMinLifetimeContrastNs', 0.025, ...
    'growthSeparationSigma', 0.75, ...
    'minCellArea', 500, ...
    'minCellCoreArea', 20, ...
    'fallbackMinContrastNs', 0.025, ...
    'fallbackCloseRadius', 7, ...
    'fallbackMinArea', 250);
cfg.pipeline = pipelineCfg;

[summary, batchInfo] = batch_immune_cell_MIET(dataRoot, cfg);

