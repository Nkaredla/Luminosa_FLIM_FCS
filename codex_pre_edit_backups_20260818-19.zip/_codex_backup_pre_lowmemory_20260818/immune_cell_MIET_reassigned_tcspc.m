function [pixelCube, pixelLinearIndices, pooledCurve, meta, fullCube] = ...
        immune_cell_MIET_reassigned_tcspc(ptu, ismResult, pixelMask, ...
        pooledMask, buildFullCube)
%IMMUNE_CELL_MIET_REASSIGNED_TCSPC Build only the TCSPC data Bayes needs.
%
% Spatially reassign photons with the same coordinate convention used by
% reassigned_flim, but histogram only selected pixels. This avoids creating
% full unassigned and reassigned image cubes for a sparse membrane fit.

    if nargin < 5 || isempty(buildFullCube)
        buildFullCube = false;
    end
    if ~(isscalar(buildFullCube) && ...
            (islogical(buildFullCube) || isnumeric(buildFullCube)))
        error('immune_cell_MIET_reassigned_tcspc:FullCubeOption', ...
            'buildFullCube must be a scalar logical/numeric value.');
    end
    buildFullCube = logical(buildFullCube);

    if ~isequal(size(pixelMask), size(pooledMask)) || ~ismatrix(pixelMask)
        error('immune_cell_MIET_reassigned_tcspc:MaskSize', ...
            'pixelMask and pooledMask must be equally sized 2-D masks.');
    end
    requiredPtu = {'head','im_col','im_line','im_tcspc','im_chan','Ngate'};
    for k = 1:numel(requiredPtu)
        if ~isfield(ptu, requiredPtu{k})
            error('immune_cell_MIET_reassigned_tcspc:PTUField', ...
                'Missing PTU field %s.', requiredPtu{k});
        end
    end
    requiredIsm = {'aprImage','channelIDs','shiftsToCenter'};
    for k = 1:numel(requiredIsm)
        if ~isfield(ismResult, requiredIsm{k})
            error('immune_cell_MIET_reassigned_tcspc:ISMField', ...
                'Missing ISM result field %s.', requiredIsm{k});
        end
    end

    imageHeight = size(ismResult.aprImage, 1);
    imageWidth = size(ismResult.aprImage, 2);
    if ~isequal(size(pixelMask), [imageHeight imageWidth])
        error('immune_cell_MIET_reassigned_tcspc:MaskGeometry', ...
            'Masks must match size(ismResult.aprImage).');
    end
    nx = double(ptu.head.ImgHdr_PixX);
    ny = double(ptu.head.ImgHdr_PixY);
    if imageHeight == ny && imageWidth == nx
        row = double(ptu.im_line(:));
        column = double(ptu.im_col(:));
        coordinateMode = 'row=line_col=col';
    elseif imageHeight == nx && imageWidth == ny
        row = double(ptu.im_col(:));
        column = double(ptu.im_line(:));
        coordinateMode = 'row=col_col=line';
    else
        error('immune_cell_MIET_reassigned_tcspc:Geometry', ...
            'ACO-ISM image dimensions do not match the PTU header.');
    end

    timeBin = round(double(ptu.im_tcspc(:)));
    channel = double(ptu.im_chan(:));
    alignedCount = min([numel(row), numel(column), numel(timeBin), numel(channel)]);
    row = row(1:alignedCount);
    column = column(1:alignedCount);
    timeBin = timeBin(1:alignedCount);
    channel = channel(1:alignedCount);

    [channelFound, channelIndex] = ismember(channel, double(ismResult.channelIDs(:)));
    if any(~channelFound)
        error('immune_cell_MIET_reassigned_tcspc:DetectorMapping', ...
            '%d photons have detector IDs absent from the ACO-ISM result.', ...
            nnz(~channelFound));
    end
    rowShift = double(ismResult.shiftsToCenter(channelIndex, 1));
    columnShift = double(ismResult.shiftsToCenter(channelIndex, 2));

    % Match reassigned_flim defaults: twofold intermediate oversampling,
    % followed by integration back onto the native-sized output grid.
    oversampling = 2;
    rowOversampled = floor((row - 0.5 + rowShift) * oversampling + 0.5);
    columnOversampled = floor((column - 0.5 + columnShift) * oversampling + 0.5);
    gateLength = round(double(ptu.Ngate));
    valid = rowOversampled >= 1 & rowOversampled <= imageHeight * oversampling & ...
        columnOversampled >= 1 & columnOversampled <= imageWidth * oversampling & ...
        timeBin >= 1 & timeBin <= gateLength;
    rowBin = floor((rowOversampled(valid) - 1) / oversampling) + 1;
    columnBin = floor((columnOversampled(valid) - 1) / oversampling) + 1;
    timeBin = timeBin(valid);
    fullPixel = sub2ind([imageHeight imageWidth], rowBin, columnBin);

    pixelLinearIndices = find(logical(pixelMask));
    selectedCount = numel(pixelLinearIndices);
    lookup = zeros(imageHeight * imageWidth, 1, 'uint32');
    lookup(pixelLinearIndices) = uint32(1:selectedCount);
    compactPixel = lookup(fullPixel);
    selectedPhoton = compactPixel > 0;
    if selectedCount == 0
        pixelCube = zeros(0, 1, gateLength, 'uint16');
    else
        pixelCube = photonCube(timeBin(selectedPhoton), ...
            double(compactPixel(selectedPhoton)), selectedCount, 1, gateLength);
    end

    pooledPhoton = logical(pooledMask(fullPixel));
    pooledCurve = accumarray(timeBin(pooledPhoton), 1, [gateLength 1], @sum, 0);
    globalCurve = accumarray(timeBin, 1, [gateLength 1], @sum, 0);
    if buildFullCube
        fullCube = photonCube(timeBin, fullPixel, imageHeight, imageWidth, gateLength);
    else
        fullCube = zeros(0, 0, 0, 'uint16');
    end
    dtNs = resolveTimeBinNs(ptu);
    meta = struct('coordinateMode', coordinateMode, ...
        'imageSize', [imageHeight imageWidth], ...
        'gateLength', gateLength, 'dtNs', dtNs, ...
        'tAxisNs', ((0:gateLength-1).' + 0.5) * dtNs, ...
        'selectedPixelCount', selectedCount, ...
        'selectedPhotonCount', nnz(selectedPhoton), ...
        'pooledPhotonCount', sum(pooledCurve), ...
        'globalCurve', globalCurve, ...
        'fullCubeStored', buildFullCube, ...
        'fullCubeClass', 'uint16', ...
        'fullCubeSize', size(fullCube), ...
        'temporalDetectorAlignmentApplied', false);
end

function dtNs = resolveTimeBinNs(ptu)
    if isfield(ptu, 'Resolution_ns') && ~isempty(ptu.Resolution_ns)
        dtNs = double(ptu.Resolution_ns);
    else
        dtNs = double(ptu.head.MeasDesc_Resolution) * 1e9;
    end
end
