function layers = immune_cell_MIET_sorted_components(bayesCompact, ...
        membranePixelIndices, imageSize, cellMask, intensity, cfg)
%IMMUNE_CELL_MIET_SORTED_COMPONENTS Build posterior-gated ordered FLIM layers.
%
% layers = immune_cell_MIET_sorted_components(bayesCompact, ...
%     membranePixelIndices, imageSize, cellMask, intensity, cfg)
%
% The fixed outside-SLB lifetime is component 1. Component 2 is the first
% membrane lifetime and is present in Bayesian models M2 and M3. Component
% 3 is the longest membrane lifetime and is present only in M3. The second
% lifetime is averaged across M2 and M3 conditional on its existence:
%
%   q2   = P(M2) + P(M3)
%   tau2 = (P(M2)*E[tau2|M2] + P(M3)*E[tau2|M3]) / q2
%
% while q3=P(M3) and tau3=E[tau3|M3]. Display maps are posterior- and
% photon-gated copies of the ungated maps; inference results are retained.
%
% cfg fields (all optional)
%   posteriorThreshold  scalar or [component2 component3], default 0.8
%   minExpectedPhotons  scalar or [component2 component3], default 10

% Expected component photons are the observed pixel photon count multiplied
% by the corresponding model-averaged posterior photon fraction.

    if nargin < 6 || isempty(cfg)
        cfg = struct();
    end
    cfg = fillDefaults(cfg);
    [imageSize, membranePixelIndices, cellMask, intensity] = ...
        validateGeometry(imageSize, membranePixelIndices, cellMask, intensity);

    required = {'probabilityBiexponential', 'probabilityTriexponential', ...
        'oneMembrane', 'twoMembrane', 'membrane1PhotonFraction', ...
        'membrane2PhotonFraction'};
    requireFields(bayesCompact, required, 'bayesCompact');
    requireFields(bayesCompact.oneMembrane, {'membraneLifetime1Ns'}, ...
        'bayesCompact.oneMembrane');
    requireFields(bayesCompact.twoMembrane, ...
        {'membraneLifetime1Ns', 'membraneLifetime2Ns'}, ...
        'bayesCompact.twoMembrane');

    compactCount = numel(membranePixelIndices);
    p2 = compactVector(bayesCompact.probabilityBiexponential, ...
        compactCount, 'probabilityBiexponential');
    p3 = compactVector(bayesCompact.probabilityTriexponential, ...
        compactCount, 'probabilityTriexponential');
    validateProbabilities(p2, p3);
    p2 = clampUnitInterval(p2);
    p3 = clampUnitInterval(p3);
    probabilitySum = p2 + p3;
    slightlyOverOne = isfinite(probabilitySum) & probabilitySum > 1;
    p2(slightlyOverOne) = p2(slightlyOverOne) ./ ...
        probabilitySum(slightlyOverOne);
    p3(slightlyOverOne) = p3(slightlyOverOne) ./ ...
        probabilitySum(slightlyOverOne);
    q2 = p2 + p3;
    q3 = p3;

    tau2GivenM2 = compactVector( ...
        bayesCompact.oneMembrane.membraneLifetime1Ns, compactCount, ...
        'oneMembrane.membraneLifetime1Ns');
    tau2GivenM3 = compactVector( ...
        bayesCompact.twoMembrane.membraneLifetime1Ns, compactCount, ...
        'twoMembrane.membraneLifetime1Ns');
    tau3GivenM3 = compactVector( ...
        bayesCompact.twoMembrane.membraneLifetime2Ns, compactCount, ...
        'twoMembrane.membraneLifetime2Ns');

    tau2 = conditionalMean(p2, tau2GivenM2, p3, tau2GivenM3, q2);
    tau3 = tau3GivenM3;
    tau3(~isfinite(q3) | q3 <= 0) = NaN;

    tau2Std = conditionalStd(bayesCompact, p2, tau2GivenM2, ...
        p3, tau2GivenM3, q2, compactCount);
    tau3Std = conditionalFieldOrNaN(bayesCompact.twoMembrane, ...
        'membraneLifetime2StdNs', compactCount);
    tau3Std(~isfinite(q3) | q3 <= 0) = NaN;

    fraction2 = compactVector(bayesCompact.membrane1PhotonFraction, ...
        compactCount, 'membrane1PhotonFraction');
    fraction3 = compactVector(bayesCompact.membrane2PhotonFraction, ...
        compactCount, 'membrane2PhotonFraction');
    validateFractions(fraction2, fraction3);
    fraction2 = clampUnitInterval(fraction2);
    fraction3 = clampUnitInterval(fraction3);
    compactIntensity = double(intensity(membranePixelIndices));
    expectedPhotons2 = compactIntensity .* fraction2;
    expectedPhotons3 = compactIntensity .* fraction3;

    inCell = logical(cellMask(membranePixelIndices));
    finiteSecond = isfinite(q2) & isfinite(tau2) & ...
        isfinite(expectedPhotons2);
    finiteThird = isfinite(q3) & isfinite(tau3) & ...
        isfinite(expectedPhotons3);
    secondProbabilityMask = inCell & finiteSecond & ...
        q2 >= cfg.posteriorThreshold(1);
    thirdProbabilityMask = inCell & finiteThird & ...
        q3 >= cfg.posteriorThreshold(2);
    secondDisplayMask = secondProbabilityMask & ...
        expectedPhotons2 >= cfg.minExpectedPhotons(1);
    thirdBeforeNesting = thirdProbabilityMask & ...
        expectedPhotons3 >= cfg.minExpectedPhotons(2);
    thirdDisplayMask = thirdBeforeNesting & secondDisplayMask;

    layers = struct();
    layers.imageSize = imageSize;
    layers.membranePixelIndices = membranePixelIndices;
    layers.config = cfg;
    layers.probability = struct( ...
        'secondComponentPresent', scatterNumeric(q2, ...
            membranePixelIndices, imageSize), ...
        'thirdComponentPresent', scatterNumeric(q3, ...
            membranePixelIndices, imageSize));
    layers.expectedPhotonCount = struct( ...
        'secondComponent', scatterNumeric(expectedPhotons2, ...
            membranePixelIndices, imageSize), ...
        'thirdComponent', scatterNumeric(expectedPhotons3, ...
            membranePixelIndices, imageSize));
    layers.modelAveragedPhotonFraction = struct( ...
        'secondComponent', scatterNumeric(fraction2, ...
            membranePixelIndices, imageSize), ...
        'thirdComponent', scatterNumeric(fraction3, ...
            membranePixelIndices, imageSize));
    layers.ungated = struct( ...
        'secondLifetimeNs', scatterNumeric(tau2, ...
            membranePixelIndices, imageSize), ...
        'thirdLifetimeNs', scatterNumeric(tau3, ...
            membranePixelIndices, imageSize), ...
        'secondLifetimeStdNs', scatterNumeric(tau2Std, ...
            membranePixelIndices, imageSize), ...
        'thirdLifetimeStdNs', scatterNumeric(tau3Std, ...
            membranePixelIndices, imageSize));

    masks = struct();
    masks.cell = logical(cellMask);
    masks.secondHighProbability = scatterLogical(secondProbabilityMask, ...
        membranePixelIndices, imageSize);
    masks.thirdHighProbability = scatterLogical(thirdProbabilityMask, ...
        membranePixelIndices, imageSize);
    masks.secondDisplay = scatterLogical(secondDisplayMask, ...
        membranePixelIndices, imageSize);
    masks.thirdDisplayBeforeNesting = scatterLogical(thirdBeforeNesting, ...
        membranePixelIndices, imageSize);
    masks.thirdDisplay = scatterLogical(thirdDisplayMask, ...
        membranePixelIndices, imageSize);
    layers.masks = masks;

    secondDisplay = layers.ungated.secondLifetimeNs;
    secondDisplay(~masks.secondDisplay) = NaN;
    thirdDisplay = layers.ungated.thirdLifetimeNs;
    thirdDisplay(~masks.thirdDisplay) = NaN;
    layers.display = struct('secondLifetimeNs', secondDisplay, ...
        'thirdLifetimeNs', thirdDisplay);

    layers.summary = struct( ...
        'secondHighProbabilityPixelCount', nnz(masks.secondHighProbability), ...
        'thirdHighProbabilityPixelCount', nnz(masks.thirdHighProbability), ...
        'secondDisplayPixelCount', nnz(masks.secondDisplay), ...
        'thirdDisplayPixelCountBeforeNesting', ...
            nnz(masks.thirdDisplayBeforeNesting), ...
        'thirdDisplayPixelCount', nnz(masks.thirdDisplay), ...
        'thirdPixelsRemovedByNesting', ...
            nnz(masks.thirdDisplayBeforeNesting & ~masks.secondDisplay));
    layers.definitions = definitions();
end

function cfg = fillDefaults(cfg)
    if ~isstruct(cfg) || ~isscalar(cfg)
        error('immune_cell_MIET_sorted_components:Config', ...
            'cfg must be a scalar struct.');
    end
    if ~isfield(cfg, 'posteriorThreshold') || isempty(cfg.posteriorThreshold)
        cfg.posteriorThreshold = 0.8;
    end
    if ~isfield(cfg, 'minExpectedPhotons') || isempty(cfg.minExpectedPhotons)
        cfg.minExpectedPhotons = 10;
    end
    cfg.posteriorThreshold = expandPair(cfg.posteriorThreshold, ...
        'posteriorThreshold', 0, 1);
    cfg.minExpectedPhotons = expandPair(cfg.minExpectedPhotons, ...
        'minExpectedPhotons', 0, Inf);
end

function value = expandPair(value, name, lowerBound, upperBound)
    validateattributes(value, {'numeric'}, {'real','finite','vector','nonempty'}, ...
        mfilename, ['cfg.' name]);
    value = double(value(:)).';
    if isscalar(value)
        value = [value value];
    elseif numel(value) ~= 2
        error('immune_cell_MIET_sorted_components:ConfigPair', ...
            'cfg.%s must be a scalar or a two-element vector.', name);
    end
    if any(value < lowerBound | value > upperBound)
        error('immune_cell_MIET_sorted_components:ConfigRange', ...
            'cfg.%s values must lie in [%g, %g].', ...
            name, lowerBound, upperBound);
    end
end

function [imageSize, indices, cellMask, intensity] = validateGeometry( ...
        imageSize, indices, cellMask, intensity)
    validateattributes(imageSize, {'numeric'}, ...
        {'real','finite','vector','numel',2,'integer','positive'}, ...
        mfilename, 'imageSize');
    imageSize = double(imageSize(:)).';
    if ~isequal(size(cellMask), imageSize) || ~isequal(size(intensity), imageSize)
        error('immune_cell_MIET_sorted_components:ImageGeometry', ...
            'cellMask and intensity must both have size [%d %d].', ...
            imageSize(1), imageSize(2));
    end
    if ~(isnumeric(cellMask) || islogical(cellMask)) || ~isreal(cellMask)
        error('immune_cell_MIET_sorted_components:CellMask', ...
            'cellMask must be a real numeric or logical array.');
    end
    if ~isnumeric(intensity) || ~isreal(intensity) || ...
            any(isfinite(intensity(:)) & intensity(:) < 0)
        error('immune_cell_MIET_sorted_components:Intensity', ...
            'intensity must be a real numeric nonnegative image.');
    end
    if any(~isfinite(intensity(:)))
        error('immune_cell_MIET_sorted_components:IntensityFinite', ...
            'intensity must contain only finite values.');
    end
    validateattributes(indices, {'numeric'}, ...
        {'real','finite','vector','integer','positive'}, ...
        mfilename, 'membranePixelIndices');
    indices = double(indices(:));
    if any(indices > prod(imageSize)) || numel(unique(indices)) ~= numel(indices)
        error('immune_cell_MIET_sorted_components:PixelIndices', ...
            ['membranePixelIndices must be unique valid linear indices ' ...
             'into imageSize.']);
    end
    cellMask = logical(cellMask);
end

function requireFields(value, names, label)
    if ~isstruct(value) || ~isscalar(value)
        error('immune_cell_MIET_sorted_components:BayesStruct', ...
            '%s must be a scalar struct.', label);
    end
    missing = names(~isfield(value, names));
    if ~isempty(missing)
        error('immune_cell_MIET_sorted_components:BayesField', ...
            '%s is missing required field %s.', label, missing{1});
    end
end

function value = compactVector(value, expectedCount, label)
    if ~isnumeric(value) || ~isreal(value) || numel(value) ~= expectedCount
        error('immune_cell_MIET_sorted_components:CompactField', ...
            '%s must be a real numeric array with %d elements.', ...
            label, expectedCount);
    end
    value = double(value(:));
end

function validateProbabilities(p2, p3)
    tolerance = 1e-5;
    finite = isfinite(p2) & isfinite(p3);
    invalid = finite & (p2 < -tolerance | p3 < -tolerance | ...
        p2 > 1 + tolerance | p3 > 1 + tolerance | ...
        p2 + p3 > 1 + tolerance);
    if any(invalid)
        error('immune_cell_MIET_sorted_components:ModelProbability', ...
            'Bayesian model probabilities must be nonnegative and sum to at most one.');
    end
end

function validateFractions(first, second)
    tolerance = 1e-5;
    invalid = (isfinite(first) & (first < -tolerance | first > 1 + tolerance)) | ...
        (isfinite(second) & (second < -tolerance | second > 1 + tolerance));
    if any(invalid)
        error('immune_cell_MIET_sorted_components:PhotonFraction', ...
            'Model-averaged component photon fractions must lie in [0,1].');
    end
end

function value = clampUnitInterval(value)
    finite = isfinite(value);
    value(finite) = min(max(value(finite), 0), 1);
end

function meanValue = conditionalMean(w1, value1, w2, value2, totalWeight)
    meanValue = nan(size(totalWeight));
    valid = isfinite(totalWeight) & totalWeight > 0 & ...
        isfinite(w1) & isfinite(w2) & ...
        (w1 <= 0 | isfinite(value1)) & (w2 <= 0 | isfinite(value2));
    term1 = zeros(size(totalWeight));
    term2 = zeros(size(totalWeight));
    use1 = valid & w1 > 0;
    use2 = valid & w2 > 0;
    term1(use1) = w1(use1) .* value1(use1);
    term2(use2) = w2(use2) .* value2(use2);
    meanValue(valid) = (term1(valid) + term2(valid)) ./ totalWeight(valid);
end

function stdValue = conditionalStd(bayes, w1, mean1, w2, mean2, ...
        totalWeight, compactCount)
    stdValue = nan(compactCount, 1);
    if ~isfield(bayes.oneMembrane, 'membraneLifetime1StdNs') || ...
            ~isfield(bayes.twoMembrane, 'membraneLifetime1StdNs')
        return;
    end
    std1 = compactVector(bayes.oneMembrane.membraneLifetime1StdNs, ...
        compactCount, 'oneMembrane.membraneLifetime1StdNs');
    std2 = compactVector(bayes.twoMembrane.membraneLifetime1StdNs, ...
        compactCount, 'twoMembrane.membraneLifetime1StdNs');
    meanValue = conditionalMean(w1, mean1, w2, mean2, totalWeight);
    valid = isfinite(meanValue) & isfinite(w1) & isfinite(w2) & ...
        totalWeight > 0 & ...
        (w1 <= 0 | (isfinite(mean1) & isfinite(std1))) & ...
        (w2 <= 0 | (isfinite(mean2) & isfinite(std2)));
    term1 = zeros(compactCount, 1);
    term2 = zeros(compactCount, 1);
    use1 = valid & w1 > 0;
    use2 = valid & w2 > 0;
    term1(use1) = w1(use1) .* ...
        (std1(use1) .^ 2 + mean1(use1) .^ 2);
    term2(use2) = w2(use2) .* ...
        (std2(use2) .^ 2 + mean2(use2) .^ 2);
    secondMoment = zeros(compactCount, 1);
    secondMoment(valid) = (term1(valid) + term2(valid)) ./ totalWeight(valid);
    stdValue(valid) = sqrt(max(secondMoment(valid) - meanValue(valid) .^ 2, 0));
end

function value = conditionalFieldOrNaN(container, name, compactCount)
    value = nan(compactCount, 1);
    if isfield(container, name)
        value = compactVector(container.(name), compactCount, name);
    end
end

function map = scatterNumeric(values, indices, imageSize)
    map = nan(imageSize, 'single');
    map(indices) = single(values);
end

function map = scatterLogical(values, indices, imageSize)
    map = false(imageSize);
    map(indices) = logical(values);
end

function value = definitions()
    value = struct();
    value.component1 = ['The globally fixed outside-SLB lifetime; it is not ' ...
        'plotted by this helper.'];
    value.component2 = ['The first ordered membrane lifetime. Its ungated ' ...
        'value is averaged across M2 and M3 conditional on component presence.'];
    value.component3 = ['The longest ordered membrane lifetime conditional ' ...
        'on M3 (fixed SLB plus two membrane lifetimes).'];
    value.secondPresenceProbability = 'P(M2)+P(M3).';
    value.thirdPresenceProbability = 'P(M3).';
    value.expectedPhotonCount = ['Observed reassigned pixel photons multiplied ' ...
        'by the posterior model-averaged component photon fraction.'];
    value.displayGate = ['A component is displayed only when its presence ' ...
        'probability and expected photon count meet the configured thresholds.'];
    value.nesting = ['The third-component display mask is intersected with ' ...
        'the second-component display mask.'];
    value.probabilityQualification = ['Model probabilities are conditional on ' ...
        'the configured lifetime/fraction grids and model priors.'];
end
