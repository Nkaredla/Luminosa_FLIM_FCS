function [masks, diagnostics] = immune_cell_MIET_segment(intensity, meanArrivalNs, cfg)
%IMMUNE_CELL_MIET_SEGMENT Segment a basal cell-membrane footprint from SLB.
%
% [masks, diagnostics] = immune_cell_MIET_segment(intensity, ...
%     meanArrivalNs, cfg)
%
% Segments a cell-membrane footprint from the surrounding supported lipid
% bilayer (SLB) in one reassigned FLIM channel.  The primary contrast is the
% longer mean photon-arrival time of the labelled cell membrane.  Intensity
% is used as a photon-confidence weight, not as a required bright/dark cell
% contrast.  No figures, dialogs, or other GUI objects are created.
%
% Inputs
%   intensity       2-D reassigned photon-count image.
%   meanArrivalNs   2-D mean photon-arrival-time image in ns. NaNs are OK.
%   cfg             Optional scalar structure. Important fields are:
%       minPhotonsPerPixel       reliable-pixel threshold (default 5)
%       smoothSigma              weighted-FLIM smoothing, pixels (1.25)
%       slbSeedMask              known outside-SLB pixels ([] = border)
%       cellSeedMask             known cell pixels ([] = automatic)
%       minLifetimeContrastNs    cell-core excess over SLB (0.15 ns)
%       cellSeparationSigma      cell-core excess in SLB MAD units (2.5)
%       minCellArea              [] chooses an image-size default
%       cellCloseRadius          closing radius, pixels (2)
%       cellDilateRadius         final dilation radius, pixels (1)
%       slbGuardRadius           exclusion around cell, pixels (3)
%       maxCellComponents        largest components retained (Inf)
%
% Masks
%   valid                 finite lifetime with enough detected photons.
%   cellFootprint         filled spatial footprint, including low-count gaps.
%   cellMembrane          cellFootprint restricted to valid fitting pixels.
%   cellCore              high-confidence long-arrival cell pixels.
%   cellBoundary          geometric perimeter of cellFootprint.
%   outsideSlbGeometry    all pixels outside the guarded cell footprint,
%                        including low-count and zero-count pixels.
%   outsideSlb            valid, border-connected SLB outside the guard band.
%   slbReference          stable subset recommended for pooled SLB TCSPC.
%   transitionBand        valid pixels deliberately excluded between classes.
%
% The reported SLB mean-arrival value is a segmentation statistic.  It is
% not an exponential lifetime.  The fixed SLB lifetime for Bayesian unmixing
% must be estimated by fitting the pooled slbReference TCSPC decay with the
% measured IRF.

    if nargin < 3 || isempty(cfg)
        cfg = struct();
    end
    validateInputs(intensity, meanArrivalNs, cfg);
    cfg = fillDefaults(cfg, size(intensity));
    validateConfig(cfg, size(intensity));
    requireImageProcessingToolbox();

    intensity = double(intensity);
    meanArrivalNs = double(meanArrivalNs);
    imageSize = size(intensity);

    finiteIntensity = isfinite(intensity) & intensity >= 0;
    valid = finiteIntensity & isfinite(meanArrivalNs) & ...
        meanArrivalNs >= 0 & intensity >= cfg.minPhotonsPerPixel;
    if nnz(valid) < cfg.minimumValidPixels
        error('immune_cell_MIET_segment:InsufficientData', ...
            ['Only %d pixels have finite mean arrival and at least %g photons; ' ...
             'at least %d are required.'], nnz(valid), ...
            cfg.minPhotonsPerPixel, cfg.minimumValidPixels);
    end

    [smoothTau, smoothWeight, smoothSupport, cappedWeight] = ...
        weightedSmooth(meanArrivalNs, intensity, valid, cfg);
    analysisSupport = isfinite(smoothTau) & ...
        smoothWeight >= cfg.minSmoothedPhotonWeight & ...
        smoothSupport >= cfg.minValidNeighbourFraction;
    if nnz(analysisSupport) < cfg.minimumValidPixels
        error('immune_cell_MIET_segment:InsufficientSupport', ...
            'Weighted smoothing left only %d supported pixels.', ...
            nnz(analysisSupport));
    end

    borderMask = makeBorderMask(imageSize, cfg.borderWidthPixels);
    if isempty(cfg.slbSeedMask)
        initialSlbSeed = analysisSupport & borderMask;
        seedSource = 'automatic image border';
        if nnz(initialSlbSeed) < cfg.minimumSlbPixels
            initialSlbSeed = analysisSupport;
            seedSource = 'all supported pixels (border had too few pixels)';
        end
    else
        initialSlbSeed = logical(cfg.slbSeedMask) & analysisSupport;
        seedSource = 'cfg.slbSeedMask';
    end
    if nnz(initialSlbSeed) < cfg.minimumSlbPixels
        error('immune_cell_MIET_segment:InsufficientSLBSeed', ...
            'The SLB seed contains %d supported pixels; at least %d are required.', ...
            nnz(initialSlbSeed), cfg.minimumSlbPixels);
    end

    supportedValues = smoothTau(analysisSupport);
    supportedWeights = cappedWeight(analysisSupport);
    globalLowLocation = weightedQuantile(supportedValues, supportedWeights, 0.45);
    [slbLocation, slbScale, slbEstimateCount] = estimateLowPopulation( ...
        smoothTau, cappedWeight, initialSlbSeed, globalLowLocation, cfg);
    [otsuThreshold, otsuRange] = lifetimeOtsuThreshold( ...
        smoothTau, analysisSupport, cappedWeight);

    cellFootprint = false(imageSize);
    cellCore = false(imageSize);
    coreThreshold = Inf;
    growthThreshold = Inf;
    iterationsCompleted = 0;
    fallbackInfo = struct('used', false, 'method', '', ...
        'coreThresholdNs', NaN, 'growthThresholdNs', NaN, ...
        'intensityFallbackUsed', false);
    for iteration = 1:cfg.refinementIterations
        effectiveSlbScale = max(slbScale, cfg.minSlbSigmaNs);
        robustCoreThreshold = slbLocation + max( ...
            cfg.minLifetimeContrastNs, ...
            cfg.cellSeparationSigma * effectiveSlbScale);
        if isfinite(otsuThreshold)
            coreThreshold = max(robustCoreThreshold, otsuThreshold);
        else
            coreThreshold = robustCoreThreshold;
        end
        growthThreshold = slbLocation + max( ...
            cfg.growthMinLifetimeContrastNs, ...
            cfg.growthSeparationSigma * effectiveSlbScale);
        growthThreshold = max(growthThreshold, slbLocation + ...
            cfg.growthFractionOfCore * (coreThreshold - slbLocation));
        growthThreshold = min(growthThreshold, coreThreshold);

        [cellFootprint, cellCore] = segmentFromThresholds( ...
            smoothTau, analysisSupport, coreThreshold, growthThreshold, ...
            cfg.cellSeedMask, cfg);
        exteriorSpatial = outsideOfCell(cellFootprint, cfg.slbGuardRadius, ...
            cfg.slbSeedMask);
        refinementSeed = exteriorSpatial & analysisSupport;
        iterationsCompleted = iteration;

        if iteration >= cfg.refinementIterations || ...
                ~any(cellFootprint(:)) || ...
                nnz(refinementSeed) < cfg.minimumSlbPixels
            break;
        end
        [newLocation, newScale, newCount] = estimateLowPopulation( ...
            smoothTau, cappedWeight, refinementSeed, Inf, cfg);
        if isfinite(newLocation) && isfinite(newScale)
            slbLocation = newLocation;
            slbScale = newScale;
            slbEstimateCount = newCount;
        end
    end

    % A sparse photon image can leave the conservative hysteresis core in
    % many small islands, even when the central cell footprint is visually
    % obvious. In that case use a lower lifetime-excess seed, bridge nearby
    % islands, and retain the most plausible large central component.
    if ~any(cellFootprint(:)) && cfg.enableCentralFootprintFallback
        [cellFootprint, cellCore, fallbackInfo] = centralFootprintFallback( ...
            smoothTau, diagnosticsIntensity(intensity), analysisSupport, ...
            slbLocation, effectiveScaleForFallback(slbScale, cfg), cfg);
    end

    % Recalculate the exterior after the last refinement pass. A guard band
    % prevents mixed edge pixels entering the pooled fixed-SLB decay.
    exteriorSpatial = outsideOfCell(cellFootprint, cfg.slbGuardRadius, ...
        cfg.slbSeedMask);
    outsideSlb = exteriorSpatial & valid;
    effectiveSlbScale = max(slbScale, cfg.minSlbSigmaNs);
    referenceRange = slbLocation + effectiveSlbScale * ...
        [-cfg.slbReferenceLowerSigma, cfg.slbReferenceUpperSigma];
    slbReference = outsideSlb & isfinite(smoothTau) & ...
        smoothTau >= referenceRange(1) & smoothTau <= referenceRange(2);

    messages = {};
    referenceFallbackUsed = false;
    if nnz(slbReference) < cfg.minimumSlbPixels && ...
            nnz(outsideSlb) >= cfg.minimumSlbPixels
        slbReference = outsideSlb;
        referenceFallbackUsed = true;
        messages{end + 1} = ...
            'Stable-SLB filtering was too restrictive; outsideSlb is used as slbReference.';
    end

    cellMembrane = cellFootprint & valid;
    cellBoundary = bwperim(cellFootprint, 8);
    transitionBand = valid & ~cellMembrane & ~outsideSlb;
    labelMap = zeros(imageSize, 'uint8');
    labelMap(outsideSlb) = 1;
    labelMap(transitionBand) = 2;
    labelMap(cellMembrane) = 3;

    masks = struct();
    masks.valid = valid;
    masks.cellFootprint = cellFootprint;
    masks.cellMembrane = cellMembrane;
    masks.cellCore = cellCore & cellFootprint;
    masks.cellBoundary = cellBoundary;
    masks.outsideSlbGeometry = exteriorSpatial;
    masks.outsideSlb = outsideSlb;
    masks.slbReference = slbReference;
    masks.transitionBand = transitionBand;
    masks.labelMap = labelMap;

    cellMedian = weightedMedianForMask( ...
        smoothTau, cappedWeight, cellMembrane);
    outsideMedian = weightedMedianForMask( ...
        smoothTau, cappedWeight, outsideSlb);
    lifetimeContrast = cellMedian - slbLocation;
    componentSummary = summariseComponents( ...
        cellFootprint, intensity, meanArrivalNs);

    touchesBorder = any(cellFootprint(borderMask & makeBorderMask(imageSize, 1)));
    if ~any(cellFootprint(:))
        status = 'no_cell_detected';
        messages{end + 1} = ...
            'No spatially coherent long-arrival cell component passed the thresholds.';
    elseif nnz(slbReference) < cfg.minimumSlbPixels
        status = 'insufficient_slb_reference';
        messages{end + 1} = ...
            'Too few outside-SLB reference pixels remain for a stable pooled decay.';
    elseif ~isfinite(lifetimeContrast) || ...
            lifetimeContrast < cfg.minLifetimeContrastNs
        status = 'weak_lifetime_separation';
        messages{end + 1} = ...
            'The filled cell footprint has weak mean-arrival contrast relative to the SLB.';
    else
        status = 'ok';
    end
    if touchesBorder && isempty(cfg.slbSeedMask)
        messages{end + 1} = ...
            ['The cell footprint touches the image edge; verify slbReference or ' ...
             'supply cfg.slbSeedMask for a known outside region.'];
    end

    diagnostics = struct();
    diagnostics.method = ...
        'photon-weighted mean-arrival hysteresis with border-connected SLB';
    if fallbackInfo.used
        diagnostics.method = sprintf('%s; %s', diagnostics.method, fallbackInfo.method);
    end
    diagnostics.status = status;
    diagnostics.messages = messages;
    diagnostics.config = cfg;
    diagnostics.smoothedMeanArrivalNs = smoothTau;
    diagnostics.smoothedPhotonWeight = smoothWeight;
    diagnostics.smoothedValidSupport = smoothSupport;
    diagnostics.analysisSupport = analysisSupport;
    diagnostics.normalisedLogIntensity = robustNormaliseLocal(log1p(intensity));
    diagnostics.lifetimeExcessZ = (smoothTau - slbLocation) ./ effectiveSlbScale;
    diagnostics.borderMask = borderMask;
    diagnostics.initialSlbSeedMask = initialSlbSeed;
    diagnostics.exteriorSpatialMask = exteriorSpatial;
    diagnostics.thresholds = struct( ...
        'slbMeanArrivalNs', slbLocation, ...
        'slbRobustSigmaNs', slbScale, ...
        'effectiveSlbSigmaNs', effectiveSlbScale, ...
        'otsuMeanArrivalNs', otsuThreshold, ...
        'otsuRobustRangeNs', otsuRange, ...
        'cellCoreMeanArrivalNs', coreThreshold, ...
        'cellGrowthMeanArrivalNs', growthThreshold, ...
        'slbReferenceRangeNs', referenceRange);
    diagnostics.slb = struct( ...
        'seedSource', seedSource, ...
        'meanArrivalNs', slbLocation, ...
        'robustSigmaNs', slbScale, ...
        'outsideMedianMeanArrivalNs', outsideMedian, ...
        'estimatePixelCount', slbEstimateCount, ...
        'referencePixelCount', nnz(slbReference), ...
        'referencePhotonCount', sumFinite(intensity(slbReference)), ...
        'referenceFallbackUsed', referenceFallbackUsed);
    diagnostics.cell = struct( ...
        'medianMeanArrivalNs', cellMedian, ...
        'contrastOverSlbNs', lifetimeContrast, ...
        'separationInSlbSigma', lifetimeContrast / effectiveSlbScale, ...
        'touchesImageBorder', touchesBorder, ...
        'components', componentSummary);
    diagnostics.pixelCounts = struct( ...
        'image', numel(intensity), ...
        'valid', nnz(valid), ...
        'cellFootprint', nnz(cellFootprint), ...
        'cellMembrane', nnz(cellMembrane), ...
        'cellCore', nnz(masks.cellCore), ...
        'outsideSlbGeometry', nnz(exteriorSpatial), ...
        'outsideSlb', nnz(outsideSlb), ...
        'slbReference', nnz(slbReference), ...
        'transitionBand', nnz(transitionBand));
    diagnostics.refinementIterationsCompleted = iterationsCompleted;
    diagnostics.fallback = fallbackInfo;
    diagnostics.labelLegend = struct( ...
        'unclassified', uint8(0), 'outsideSlb', uint8(1), ...
        'transitionBand', uint8(2), 'cellMembrane', uint8(3));
    diagnostics.assumptions = { ...
        'Cell-membrane pixels have later mean arrival than the surrounding SLB.', ...
        'Outside SLB is connected to an image edge unless cfg.slbSeedMask is supplied.', ...
        'cellFootprint denotes the filled basal-membrane analysis domain, not only its perimeter.', ...
        'SLB mean arrival is for segmentation only; fit pooled SLB TCSPC with the IRF to fix tau_SLB.'};
end

function cfg = fillDefaults(cfg, imageSize)
    pixelCount = prod(imageSize);
    defaults = struct();
    defaults.minPhotonsPerPixel = 5;
    defaults.smoothSigma = 1.25;
    defaults.minSmoothedPhotonWeight = 2.5;
    defaults.minValidNeighbourFraction = 0.20;
    defaults.intensityWeightCapQuantile = 0.99;
    defaults.borderFraction = 0.12;
    defaults.borderWidthPixels = [];
    defaults.slbSeedMask = [];
    defaults.cellSeedMask = [];
    defaults.minimumValidPixels = max(20, ceil(0.001 * pixelCount));
    defaults.minimumSlbPixels = max(20, ceil(0.001 * pixelCount));
    defaults.minSlbSigmaNs = 0.03;
    defaults.slbClipSigma = 3.0;
    defaults.cellSeparationSigma = 2.5;
    defaults.minLifetimeContrastNs = 0.15;
    defaults.growthSeparationSigma = 1.25;
    defaults.growthMinLifetimeContrastNs = 0.075;
    defaults.growthFractionOfCore = 0.50;
    defaults.minCellArea = max(20, ceil(0.002 * pixelCount));
    defaults.minCellCoreArea = [];
    defaults.cellCloseRadius = 2;
    defaults.cellDilateRadius = 1;
    defaults.slbGuardRadius = 3;
    defaults.maxCellComponents = Inf;
    defaults.refinementIterations = 2;
    defaults.slbReferenceLowerSigma = 3.0;
    defaults.slbReferenceUpperSigma = 2.5;
    defaults.enableCentralFootprintFallback = true;
    defaults.fallbackLifetimeQuantile = 0.75;
    defaults.fallbackContrastFraction = 0.30;
    defaults.fallbackGrowthFraction = 0.12;
    defaults.fallbackMinContrastNs = 0.03;
    defaults.fallbackCloseRadius = max(4, ceil(0.008 * min(imageSize)));
    defaults.fallbackDilateRadius = 2;
    defaults.fallbackMinArea = max(20, ceil(0.0005 * pixelCount));
    defaults.fallbackCentralityWeight = 0.35;
    defaults.fallbackUseIntensity = true;
    defaults.fallbackIntensityCoreLevel = 0.60;
    defaults.fallbackIntensityGrowthLevel = 0.30;

    names = fieldnames(defaults);
    for k = 1:numel(names)
        if ~isfield(cfg, names{k}) || isempty(cfg.(names{k}))
            cfg.(names{k}) = defaults.(names{k});
        end
    end
    if isempty(cfg.borderWidthPixels)
        cfg.borderWidthPixels = max(1, ceil(cfg.borderFraction * min(imageSize)));
    end
    if isempty(cfg.minCellCoreArea)
        cfg.minCellCoreArea = max(3, ceil(0.10 * cfg.minCellArea));
    end
end

function validateInputs(intensity, meanArrivalNs, cfg)
    if ~(isnumeric(intensity) || islogical(intensity)) || ...
            ~isreal(intensity) || isempty(intensity) || ~ismatrix(intensity)
        error('immune_cell_MIET_segment:IntensityInput', ...
            'intensity must be a nonempty real 2-D numeric image.');
    end
    if ~isnumeric(meanArrivalNs) || ~isreal(meanArrivalNs) || ...
            isempty(meanArrivalNs) || ~ismatrix(meanArrivalNs)
        error('immune_cell_MIET_segment:LifetimeInput', ...
            'meanArrivalNs must be a nonempty real 2-D numeric image.');
    end
    if ~isequal(size(intensity), size(meanArrivalNs))
        error('immune_cell_MIET_segment:ImageSize', ...
            'intensity and meanArrivalNs must have identical sizes.');
    end
    if any(isfinite(intensity(:)) & intensity(:) < 0)
        error('immune_cell_MIET_segment:NegativeIntensity', ...
            'intensity cannot contain finite negative photon counts.');
    end
    if ~isstruct(cfg) || ~isscalar(cfg)
        error('immune_cell_MIET_segment:ConfigInput', ...
            'cfg must be a scalar structure.');
    end
end

function validateConfig(cfg, imageSize)
    nonnegativeScalar(cfg.minPhotonsPerPixel, 'minPhotonsPerPixel');
    nonnegativeScalar(cfg.smoothSigma, 'smoothSigma');
    nonnegativeScalar(cfg.minSmoothedPhotonWeight, 'minSmoothedPhotonWeight');
    boundedScalar(cfg.minValidNeighbourFraction, 0, 1, ...
        'minValidNeighbourFraction');
    boundedScalar(cfg.intensityWeightCapQuantile, eps, 1, ...
        'intensityWeightCapQuantile');
    boundedScalar(cfg.borderFraction, eps, 0.5, 'borderFraction');
    positiveInteger(cfg.borderWidthPixels, 'borderWidthPixels');
    positiveInteger(cfg.minimumValidPixels, 'minimumValidPixels');
    positiveInteger(cfg.minimumSlbPixels, 'minimumSlbPixels');
    nonnegativeScalar(cfg.minSlbSigmaNs, 'minSlbSigmaNs');
    nonnegativeScalar(cfg.slbClipSigma, 'slbClipSigma');
    nonnegativeScalar(cfg.cellSeparationSigma, 'cellSeparationSigma');
    nonnegativeScalar(cfg.minLifetimeContrastNs, 'minLifetimeContrastNs');
    nonnegativeScalar(cfg.growthSeparationSigma, 'growthSeparationSigma');
    nonnegativeScalar(cfg.growthMinLifetimeContrastNs, ...
        'growthMinLifetimeContrastNs');
    boundedScalar(cfg.growthFractionOfCore, 0, 1, 'growthFractionOfCore');
    positiveInteger(cfg.minCellArea, 'minCellArea');
    positiveInteger(cfg.minCellCoreArea, 'minCellCoreArea');
    nonnegativeInteger(cfg.cellCloseRadius, 'cellCloseRadius');
    nonnegativeInteger(cfg.cellDilateRadius, 'cellDilateRadius');
    nonnegativeInteger(cfg.slbGuardRadius, 'slbGuardRadius');
    if ~(isnumeric(cfg.maxCellComponents) && isscalar(cfg.maxCellComponents) && ...
            isreal(cfg.maxCellComponents) && ...
            (isinf(cfg.maxCellComponents) || ...
             (isfinite(cfg.maxCellComponents) && cfg.maxCellComponents >= 1 && ...
              cfg.maxCellComponents == round(cfg.maxCellComponents))))
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.maxCellComponents must be Inf or a positive integer.');
    end
    positiveInteger(cfg.refinementIterations, 'refinementIterations');
    nonnegativeScalar(cfg.slbReferenceLowerSigma, 'slbReferenceLowerSigma');
    nonnegativeScalar(cfg.slbReferenceUpperSigma, 'slbReferenceUpperSigma');
    if ~(islogical(cfg.enableCentralFootprintFallback) || ...
            (isnumeric(cfg.enableCentralFootprintFallback) && ...
             isscalar(cfg.enableCentralFootprintFallback)))
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.enableCentralFootprintFallback must be scalar logical/numeric.');
    end
    boundedScalar(cfg.fallbackLifetimeQuantile, 0.5, 0.99, ...
        'fallbackLifetimeQuantile');
    boundedScalar(cfg.fallbackContrastFraction, 0, 1, ...
        'fallbackContrastFraction');
    boundedScalar(cfg.fallbackGrowthFraction, 0, 1, ...
        'fallbackGrowthFraction');
    nonnegativeScalar(cfg.fallbackMinContrastNs, 'fallbackMinContrastNs');
    nonnegativeInteger(cfg.fallbackCloseRadius, 'fallbackCloseRadius');
    nonnegativeInteger(cfg.fallbackDilateRadius, 'fallbackDilateRadius');
    positiveInteger(cfg.fallbackMinArea, 'fallbackMinArea');
    boundedScalar(cfg.fallbackCentralityWeight, 0, 1, ...
        'fallbackCentralityWeight');
    boundedScalar(cfg.fallbackIntensityCoreLevel, 0, 1, ...
        'fallbackIntensityCoreLevel');
    boundedScalar(cfg.fallbackIntensityGrowthLevel, 0, 1, ...
        'fallbackIntensityGrowthLevel');
    validateOptionalMask(cfg.slbSeedMask, imageSize, 'slbSeedMask');
    validateOptionalMask(cfg.cellSeedMask, imageSize, 'cellSeedMask');
end

function scale = effectiveScaleForFallback(slbScale, cfg)
    scale = max(double(slbScale), cfg.minSlbSigmaNs);
    if ~isfinite(scale)
        scale = cfg.minSlbSigmaNs;
    end
end

function normalised = diagnosticsIntensity(intensity)
    normalised = robustNormaliseLocal(log1p(max(double(intensity), 0)));
end

function [footprint, core, info] = centralFootprintFallback( ...
        smoothTau, normalisedIntensity, support, slbLocation, slbScale, cfg)
    footprint = false(size(support));
    core = false(size(support));
    info = struct('used', false, 'method', '', ...
        'coreThresholdNs', NaN, 'growthThresholdNs', NaN, ...
        'intensityFallbackUsed', false);
    values = smoothTau(support & isfinite(smoothTau));
    if isempty(values) || ~isfinite(slbLocation)
        return;
    end

    highLifetime = finiteQuantile(values, cfg.fallbackLifetimeQuantile);
    availableContrast = max(highLifetime - slbLocation, 0);
    coreContrast = max([cfg.fallbackMinContrastNs, ...
        cfg.fallbackContrastFraction * availableContrast, 0.5 * slbScale]);
    growthContrast = max(cfg.fallbackGrowthFraction * coreContrast, ...
        min(0.5 * cfg.fallbackMinContrastNs, coreContrast));
    coreThreshold = slbLocation + coreContrast;
    growthThreshold = slbLocation + growthContrast;
    core = support & smoothTau >= coreThreshold;
    growthMask = support & smoothTau >= growthThreshold;

    if nnz(core) < max(3, ceil(0.1 * cfg.fallbackMinArea)) && ...
            cfg.fallbackUseIntensity
        core = support & normalisedIntensity >= cfg.fallbackIntensityCoreLevel;
        growthMask = support & ...
            normalisedIntensity >= cfg.fallbackIntensityGrowthLevel;
        info.intensityFallbackUsed = true;
    end
    core = bwareaopen(core, max(3, ceil(0.05 * cfg.fallbackMinArea)), 8);
    if ~any(core(:))
        return;
    end
    growthMask = growthMask | core;
    candidate = imreconstruct(core, growthMask, 8);
    if cfg.fallbackCloseRadius > 0
        candidate = imclose(candidate, strel('disk', cfg.fallbackCloseRadius, 0));
    end
    candidate = imfill(candidate, 'holes');
    if cfg.fallbackDilateRadius > 0
        candidate = imdilate(candidate, strel('disk', cfg.fallbackDilateRadius, 0));
    end
    candidate = bwareaopen(candidate, cfg.fallbackMinArea, 8);
    footprint = selectCentralLifetimeComponents(candidate, smoothTau, ...
        slbLocation, cfg.maxCellComponents, cfg.fallbackCentralityWeight);
    if any(footprint(:))
        footprint = imfill(footprint, 'holes');
        core = core & footprint;
        info.used = true;
        info.method = 'central high-lifetime footprint fallback';
        info.coreThresholdNs = coreThreshold;
        info.growthThresholdNs = growthThreshold;
    else
        core(:) = false;
    end
end

function selected = selectCentralLifetimeComponents(candidate, tau, ...
        slbLocation, maximumCount, centralityWeight)
    selected = false(size(candidate));
    components = bwconncomp(candidate, 8);
    if components.NumObjects == 0
        return;
    end
    geometry = regionprops(components, 'Area', 'Centroid');
    centre = ([size(candidate, 2), size(candidate, 1)] + 1) / 2;
    distanceScale = max(min(size(candidate)) / 2, 1);
    score = zeros(components.NumObjects, 1);
    for k = 1:components.NumObjects
        distance = norm(double(geometry(k).Centroid) - centre) / distanceScale;
        centrality = exp(-0.5 * distance^2);
        tauValues = tau(components.PixelIdxList{k});
        tauValues = tauValues(isfinite(tauValues));
        if isempty(tauValues)
            lifetimeFactor = 1;
        else
            lifetimeFactor = max(median(tauValues) - slbLocation, eps);
        end
        centreFactor = (1 - centralityWeight) + centralityWeight * centrality;
        score(k) = double(geometry(k).Area) * centreFactor * lifetimeFactor;
    end
    [~, order] = sort(score, 'descend');
    if isfinite(maximumCount)
        keepCount = min(round(maximumCount), numel(order));
    else
        % Retain the dominant cell. Additional tiny components are more
        % likely debris or detached objects than the basal membrane.
        keepCount = 1;
    end
    for k = 1:keepCount
        selected(components.PixelIdxList{order(k)}) = true;
    end
end

function requireImageProcessingToolbox()
    required = {'imgaussfilt', 'graythresh', 'imreconstruct', 'imclose', ...
        'imfill', 'imdilate', 'strel', 'bwareaopen', 'bwconncomp', ...
        'bwperim', 'regionprops'};
    for k = 1:numel(required)
        if exist(required{k}, 'file') ~= 2
            error('immune_cell_MIET_segment:MissingImageProcessingToolbox', ...
                'Required Image Processing Toolbox function %s is unavailable.', ...
                required{k});
        end
    end
end

function [smoothTau, smoothWeight, smoothSupport, cappedWeight] = ...
        weightedSmooth(tau, intensity, valid, cfg)
    positiveIntensities = intensity(valid & intensity > 0);
    cap = finiteQuantile(positiveIntensities, cfg.intensityWeightCapQuantile);
    if ~isfinite(cap) || cap <= 0
        cap = max(intensity(valid));
    end
    cappedWeight = min(max(intensity, 0), cap);
    cappedWeight(~valid) = 0;
    tauForFilter = tau;
    tauForFilter(~valid) = 0;

    if cfg.smoothSigma > 0
        smoothWeight = imgaussfilt(cappedWeight, cfg.smoothSigma, ...
            'Padding', 'replicate');
        numerator = imgaussfilt(tauForFilter .* cappedWeight, ...
            cfg.smoothSigma, 'Padding', 'replicate');
        smoothSupport = imgaussfilt(double(valid), cfg.smoothSigma, ...
            'Padding', 'replicate');
    else
        smoothWeight = cappedWeight;
        numerator = tauForFilter .* cappedWeight;
        smoothSupport = double(valid);
    end
    smoothTau = numerator ./ max(smoothWeight, eps);
    smoothTau(smoothWeight <= eps) = NaN;
end

function mask = makeBorderMask(imageSize, width)
    width = min([round(width), floor(min(imageSize) / 2)]);
    width = max(width, 1);
    mask = false(imageSize);
    mask(1:width, :) = true;
    mask(end - width + 1:end, :) = true;
    mask(:, 1:width) = true;
    mask(:, end - width + 1:end) = true;
end

function [location, scale, count] = estimateLowPopulation( ...
        tau, weights, mask, locationUpperBound, cfg)
    keep = mask & isfinite(tau) & isfinite(weights) & weights > 0;
    values = tau(keep);
    pixelWeights = weights(keep);
    if isempty(values)
        location = NaN;
        scale = NaN;
        count = 0;
        return;
    end

    location = weightedQuantile(values, pixelWeights, 0.50);
    if isfinite(locationUpperBound)
        location = min(location, locationUpperBound);
    end
    lower = values <= location;
    if any(lower)
        scale = 1.4826 * weightedQuantile( ...
            location - values(lower), pixelWeights(lower), 0.50);
    else
        scale = 0;
    end
    effectiveScale = max(scale, cfg.minSlbSigmaNs);
    clipped = values >= location - cfg.slbClipSigma * effectiveScale & ...
        values <= location + cfg.slbClipSigma * effectiveScale;
    if nnz(clipped) >= min(cfg.minimumSlbPixels, numel(values))
        values = values(clipped);
        pixelWeights = pixelWeights(clipped);
        location = weightedQuantile(values, pixelWeights, 0.50);
        scale = 1.4826 * weightedQuantile( ...
            abs(values - location), pixelWeights, 0.50);
    end
    if ~isfinite(scale)
        scale = 0;
    end
    count = numel(values);
end

function [threshold, robustRange] = lifetimeOtsuThreshold(tau, mask, weights)
    values = tau(mask & isfinite(tau) & isfinite(weights) & weights > 0);
    pixelWeights = weights(mask & isfinite(tau) & isfinite(weights) & weights > 0);
    if numel(values) < 2
        threshold = Inf;
        robustRange = [NaN NaN];
        return;
    end
    low = weightedQuantile(values, pixelWeights, 0.02);
    high = weightedQuantile(values, pixelWeights, 0.98);
    robustRange = [low high];
    if ~isfinite(low) || ~isfinite(high) || high <= low
        threshold = Inf;
        return;
    end
    normalised = min(max((values - low) ./ (high - low), 0), 1);
    threshold = low + graythresh(normalised(:)) * (high - low);
end

function [cellMask, core] = segmentFromThresholds( ...
        tau, support, coreThreshold, growthThreshold, cellSeedMask, cfg)
    core = support & tau >= coreThreshold;
    if ~isempty(cellSeedMask)
        core = core | (logical(cellSeedMask) & support);
    end
    core = bwareaopen(core, cfg.minCellCoreArea, 8);
    if ~any(core(:))
        cellMask = false(size(core));
        return;
    end

    permissive = support & tau >= growthThreshold;
    permissive = permissive | core;
    cellMask = imreconstruct(core, permissive, 8);
    if cfg.cellCloseRadius > 0
        cellMask = imclose(cellMask, ...
            strel('disk', cfg.cellCloseRadius, 0));
    end
    cellMask = imfill(cellMask, 'holes');
    if cfg.cellDilateRadius > 0
        cellMask = imdilate(cellMask, ...
            strel('disk', cfg.cellDilateRadius, 0));
    end
    cellMask = bwareaopen(cellMask, cfg.minCellArea, 8);
    cellMask = keepLargestComponents(cellMask, cfg.maxCellComponents);
    cellMask = imfill(cellMask, 'holes');
    core = core & cellMask;
end

function exterior = outsideOfCell(cellMask, guardRadius, slbSeedMask)
    guardedCell = cellMask;
    if guardRadius > 0 && any(cellMask(:))
        guardedCell = imdilate(cellMask, strel('disk', guardRadius, 0));
    end
    possibleOutside = ~guardedCell;
    if isempty(slbSeedMask)
        marker = false(size(cellMask));
        marker(1, :) = possibleOutside(1, :);
        marker(end, :) = possibleOutside(end, :);
        marker(:, 1) = possibleOutside(:, 1);
        marker(:, end) = possibleOutside(:, end);
    else
        marker = logical(slbSeedMask) & possibleOutside;
    end
    exterior = imreconstruct(marker, possibleOutside, 8);
end

function mask = keepLargestComponents(mask, maximumCount)
    if ~isfinite(maximumCount)
        return;
    end
    components = bwconncomp(mask, 8);
    if components.NumObjects <= maximumCount
        return;
    end
    areas = cellfun(@numel, components.PixelIdxList);
    [~, order] = sort(areas, 'descend');
    keep = false(size(mask));
    for k = 1:maximumCount
        keep(components.PixelIdxList{order(k)}) = true;
    end
    mask = keep;
end

function summary = summariseComponents(cellMask, intensity, tau)
    components = bwconncomp(cellMask, 8);
    if components.NumObjects == 0
        summary = struct('areaPixels', {}, 'centroidXY', {}, ...
            'boundingBox', {}, 'photonCount', {}, ...
            'medianMeanArrivalNs', {});
        return;
    end
    geometry = regionprops(components, 'Area', 'Centroid', 'BoundingBox');
    summary = repmat(struct('areaPixels', 0, 'centroidXY', [NaN NaN], ...
        'boundingBox', [NaN NaN NaN NaN], 'photonCount', 0, ...
        'medianMeanArrivalNs', NaN), components.NumObjects, 1);
    for k = 1:components.NumObjects
        indices = components.PixelIdxList{k};
        tauValues = tau(indices);
        tauValues = tauValues(isfinite(tauValues));
        summary(k).areaPixels = geometry(k).Area;
        summary(k).centroidXY = geometry(k).Centroid;
        summary(k).boundingBox = geometry(k).BoundingBox;
        summary(k).photonCount = sumFinite(intensity(indices));
        if ~isempty(tauValues)
            summary(k).medianMeanArrivalNs = median(tauValues);
        end
    end
end

function value = weightedMedianForMask(values, weights, mask)
    keep = mask & isfinite(values) & isfinite(weights) & weights > 0;
    if ~any(keep(:))
        value = NaN;
    else
        value = weightedQuantile(values(keep), weights(keep), 0.50);
    end
end

function value = weightedQuantile(values, weights, probability)
    values = double(values(:));
    weights = double(weights(:));
    keep = isfinite(values) & isfinite(weights) & weights > 0;
    values = values(keep);
    weights = weights(keep);
    if isempty(values)
        value = NaN;
        return;
    end
    [values, order] = sort(values);
    weights = weights(order);
    cumulative = cumsum(weights);
    target = min(max(probability, 0), 1) * cumulative(end);
    index = find(cumulative >= target, 1, 'first');
    if isempty(index)
        index = numel(values);
    end
    value = values(index);
end

function value = finiteQuantile(values, probability)
    values = sort(double(values(isfinite(values))));
    if isempty(values)
        value = NaN;
        return;
    end
    position = 1 + (numel(values) - 1) * min(max(probability, 0), 1);
    lowerIndex = floor(position);
    upperIndex = ceil(position);
    fraction = position - lowerIndex;
    value = values(lowerIndex) * (1 - fraction) + ...
        values(upperIndex) * fraction;
end

function image = robustNormaliseLocal(image)
    finiteValues = image(isfinite(image));
    if isempty(finiteValues)
        image(:) = 0;
        return;
    end
    low = finiteQuantile(finiteValues, 0.01);
    high = finiteQuantile(finiteValues, 0.99);
    if high <= low
        image(:) = 0;
        return;
    end
    image = min(max((image - low) ./ (high - low), 0), 1);
    image(~isfinite(image)) = 0;
end

function total = sumFinite(values)
    values = double(values(:));
    total = sum(values(isfinite(values)));
end

function validateOptionalMask(mask, imageSize, name)
    if isempty(mask)
        return;
    end
    if ~(isnumeric(mask) || islogical(mask)) || ~isreal(mask) || ...
            ~isequal(size(mask), imageSize) || any(~isfinite(double(mask(:))))
        error('immune_cell_MIET_segment:ConfigMask', ...
            'cfg.%s must be a finite numeric/logical mask matching the images.', name);
    end
end

function nonnegativeScalar(value, name)
    if ~(isnumeric(value) && isscalar(value) && isreal(value) && ...
            isfinite(value) && value >= 0)
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.%s must be a finite nonnegative scalar.', name);
    end
end

function boundedScalar(value, lower, upper, name)
    if ~(isnumeric(value) && isscalar(value) && isreal(value) && ...
            isfinite(value) && value >= lower && value <= upper)
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.%s must be in [%g, %g].', name, lower, upper);
    end
end

function positiveInteger(value, name)
    if ~(isnumeric(value) && isscalar(value) && isreal(value) && ...
            isfinite(value) && value >= 1 && value == round(value))
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.%s must be a positive integer.', name);
    end
end

function nonnegativeInteger(value, name)
    if ~(isnumeric(value) && isscalar(value) && isreal(value) && ...
            isfinite(value) && value >= 0 && value == round(value))
        error('immune_cell_MIET_segment:ConfigValue', ...
            'cfg.%s must be a nonnegative integer.', name);
    end
end
